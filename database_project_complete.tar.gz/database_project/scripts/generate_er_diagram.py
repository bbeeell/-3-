#!/usr/bin/env python3
"""
Скрипт для создания ER-диаграммы базы данных ООО «Обувь»
Использует библиотеку graphviz для визуализации
"""

from graphviz import Digraph

def create_er_diagram():
    """Создание ER-диаграммы базы данных"""
    
    # Создаем новый граф
    dot = Digraph(comment='ER-диаграмма: Система управления магазином обуви',
                  format='pdf')
    
    # Настройки графа
    dot.attr(rankdir='TB', splines='ortho', nodesep='0.8', ranksep='1.2')
    dot.attr('node', shape='plaintext', fontname='Arial', fontsize='10')
    dot.attr('edge', fontname='Arial', fontsize='9')
    
    # Функция для создания таблицы
    def create_table(name, fields, pks=None, fks=None):
        if pks is None:
            pks = []
        if fks is None:
            fks = []
        
        # Заголовок таблицы
        html = f'''<
        <TABLE BORDER="1" CELLBORDER="1" CELLSPACING="0" CELLPADDING="4">
            <TR><TD BGCOLOR="#4A90E2" COLSPAN="2"><FONT COLOR="white"><B>{name}</B></FONT></TD></TR>'''
        
        # Поля таблицы
        for field in fields:
            field_name = field.split()[0]
            field_type = ' '.join(field.split()[1:])
            
            # Определяем цвет фона
            bgcolor = ''
            if field_name in pks:
                bgcolor = ' BGCOLOR="#FFD700"'  # Золотой для PK
            elif field_name in fks:
                bgcolor = ' BGCOLOR="#90EE90"'  # Зеленый для FK
            
            html += f'''
            <TR>
                <TD ALIGN="LEFT"{bgcolor}><B>{field_name}</B></TD>
                <TD ALIGN="LEFT"{bgcolor}>{field_type}</TD>
            </TR>'''
        
        html += '''
        </TABLE>
        >'''
        
        return html
    
    # Определяем таблицы
    tables = {
        'roles': {
            'fields': [
                'role_id SERIAL PK',
                'role_name VARCHAR(100)',
                'description TEXT'
            ],
            'pks': ['role_id'],
            'fks': []
        },
        'users': {
            'fields': [
                'user_id SERIAL PK',
                'role_id INT FK',
                'full_name VARCHAR(255)',
                'login VARCHAR(100)',
                'password VARCHAR(100)',
                'created_at TIMESTAMP'
            ],
            'pks': ['user_id'],
            'fks': ['role_id']
        },
        'categories': {
            'fields': [
                'category_id SERIAL PK',
                'category_name VARCHAR(100)',
                'description TEXT'
            ],
            'pks': ['category_id'],
            'fks': []
        },
        'manufacturers': {
            'fields': [
                'manufacturer_id SERIAL PK',
                'manufacturer_name VARCHAR(100)',
                'description TEXT'
            ],
            'pks': ['manufacturer_id'],
            'fks': []
        },
        'suppliers': {
            'fields': [
                'supplier_id SERIAL PK',
                'supplier_name VARCHAR(100)',
                'contact_info TEXT'
            ],
            'pks': ['supplier_id'],
            'fks': []
        },
        'pickup_points': {
            'fields': [
                'pickup_point_id SERIAL PK',
                'address VARCHAR(255)',
                'postal_code VARCHAR(10)',
                'city VARCHAR(100)',
                'street VARCHAR(100)',
                'building VARCHAR(10)'
            ],
            'pks': ['pickup_point_id'],
            'fks': []
        },
        'products': {
            'fields': [
                'product_id SERIAL PK',
                'article VARCHAR(50)',
                'product_name VARCHAR(255)',
                'unit_of_measure VARCHAR(20)',
                'price DECIMAL(10,2)',
                'supplier_id INT FK',
                'manufacturer_id INT FK',
                'category_id INT FK',
                'discount_percent INT',
                'quantity_in_stock INT',
                'description TEXT',
                'photo_filename VARCHAR(255)',
                'created_at TIMESTAMP',
                'updated_at TIMESTAMP'
            ],
            'pks': ['product_id'],
            'fks': ['supplier_id', 'manufacturer_id', 'category_id']
        },
        'orders': {
            'fields': [
                'order_id SERIAL PK',
                'order_number VARCHAR(50)',
                'user_id INT FK',
                'order_date DATE',
                'delivery_date DATE',
                'pickup_point_id INT FK',
                'pickup_code VARCHAR(10)',
                'order_status VARCHAR(50)',
                'created_at TIMESTAMP',
                'updated_at TIMESTAMP'
            ],
            'pks': ['order_id'],
            'fks': ['user_id', 'pickup_point_id']
        },
        'order_items': {
            'fields': [
                'order_item_id SERIAL PK',
                'order_id INT FK',
                'product_id INT FK',
                'quantity INT',
                'price_at_order DECIMAL(10,2)',
                'discount_at_order INT'
            ],
            'pks': ['order_item_id'],
            'fks': ['order_id', 'product_id']
        }
    }
    
    # Создаем узлы для всех таблиц
    for table_name, table_info in tables.items():
        table_html = create_table(table_name, table_info['fields'], 
                                   table_info['pks'], table_info['fks'])
        dot.node(table_name, table_html)
    
    # Определяем связи (relationships)
    relationships = [
        ('roles', 'users', '1', 'N', 'role_id'),
        ('users', 'orders', '1', 'N', 'user_id'),
        ('pickup_points', 'orders', '1', 'N', 'pickup_point_id'),
        ('suppliers', 'products', '1', 'N', 'supplier_id'),
        ('manufacturers', 'products', '1', 'N', 'manufacturer_id'),
        ('categories', 'products', '1', 'N', 'category_id'),
        ('orders', 'order_items', '1', 'N', 'order_id'),
        ('products', 'order_items', '1', 'N', 'product_id')
    ]
    
    # Добавляем связи
    for parent, child, card1, card2, fk_name in relationships:
        label = f'{card1}  ───  {card2}'
        dot.edge(parent, child, label=label, 
                color='#666666', penwidth='1.5',
                arrowhead='crow', arrowtail='none')
    
    # Добавляем заголовок
    dot.attr(label='\\n\\nER-диаграмма: База данных ООО «Обувь»\\n'
                  'Система управления магазином обуви\\n'
                  'Дата: 04.02.2026',
            labelloc='t', fontsize='14', fontname='Arial Bold')
    
    # Добавляем легенду
    with dot.subgraph(name='cluster_legend') as legend:
        legend.attr(label='Легенда', style='filled', color='lightgrey')
        legend.node('pk_legend', '<<TABLE BORDER="0" CELLBORDER="0" CELLSPACING="5">'
                   '<TR><TD BGCOLOR="#FFD700" WIDTH="50"> </TD><TD ALIGN="LEFT">Primary Key (PK)</TD></TR>'
                   '<TR><TD BGCOLOR="#90EE90" WIDTH="50"> </TD><TD ALIGN="LEFT">Foreign Key (FK)</TD></TR>'
                   '<TR><TD BGCOLOR="white" WIDTH="50"> </TD><TD ALIGN="LEFT">Обычное поле</TD></TR>'
                   '</TABLE>>')
    
    return dot

if __name__ == '__main__':
    print("Создание ER-диаграммы...")
    diagram = create_er_diagram()
    
    # Сохраняем диаграмму
    output_path = '/home/claude/database_project/diagrams/er_diagram'
    diagram.render(output_path, cleanup=True)
    print(f"ER-диаграмма успешно создана: {output_path}.pdf")
