const fs = require('fs');
const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
        AlignmentType, HeadingLevel, BorderStyle, WidthType, 
        VerticalAlign, PageBreak, ImageRun } = require('docx');

// Создание документа с результатами тестирования
async function createTestingDocument() {
    const doc = new Document({
        sections: [{
            properties: {
                page: {
                    size: {
                        width: 12240,   // US Letter width
                        height: 15840   // US Letter height
                    },
                    margin: { 
                        top: 1440,      // 1 inch
                        right: 1440, 
                        bottom: 1440, 
                        left: 1440 
                    }
                }
            },
            children: [
                // Заголовок документа
                new Paragraph({
                    text: "Отчет о тестировании системы",
                    heading: HeadingLevel.HEADING_1,
                    alignment: AlignmentType.CENTER,
                    spacing: { after: 400 }
                }),
                
                new Paragraph({
                    text: 'ООО «Обувь» - Система управления магазином обуви',
                    alignment: AlignmentType.CENTER,
                    spacing: { after: 200 }
                }),
                
                new Paragraph({
                    text: 'Дата тестирования: 04.02.2026',
                    alignment: AlignmentType.CENTER,
                    spacing: { after: 600 }
                }),
                
                // Раздел 1: Описание тестирования
                new Paragraph({
                    text: '1. Описание проведенного тестирования',
                    heading: HeadingLevel.HEADING_2,
                    spacing: { before: 400, after: 200 }
                }),
                
                new Paragraph({
                    text: 'Проведено полное функциональное тестирование разработанной информационной системы для магазина обуви ООО «Обувь». Протестированы все основные модули и функции системы согласно требованиям задания.',
                    spacing: { after: 200 }
                }),
                
                // Раздел 2: Структура базы данных
                new Paragraph({
                    text: '2. Структура базы данных',
                    heading: HeadingLevel.HEADING_2,
                    spacing: { before: 400, after: 200 }
                }),
                
                new Paragraph({
                    text: 'База данных успешно создана в третьей нормальной форме (3НФ) с соблюдением ссылочной целостности. Структура включает следующие таблицы:',
                    spacing: { after: 200 }
                }),
                
                // Таблица структуры БД
                new Table({
                    width: { size: 100, type: WidthType.PERCENTAGE },
                    rows: [
                        new TableRow({
                            children: [
                                new TableCell({
                                    children: [new Paragraph({ 
                                        text: 'Название таблицы', 
                                        bold: true 
                                    })],
                                    shading: { fill: "4A90E2" },
                                    verticalAlign: VerticalAlign.CENTER
                                }),
                                new TableCell({
                                    children: [new Paragraph({ 
                                        text: 'Назначение', 
                                        bold: true 
                                    })],
                                    shading: { fill: "4A90E2" },
                                    verticalAlign: VerticalAlign.CENTER
                                }),
                                new TableCell({
                                    children: [new Paragraph({ 
                                        text: 'Количество полей', 
                                        bold: true 
                                    })],
                                    shading: { fill: "4A90E2" },
                                    verticalAlign: VerticalAlign.CENTER
                                })
                            ]
                        }),
                        new TableRow({
                            children: [
                                new TableCell({ children: [new Paragraph('roles')] }),
                                new TableCell({ children: [new Paragraph('Роли пользователей')] }),
                                new TableCell({ children: [new Paragraph('3')] })
                            ]
                        }),
                        new TableRow({
                            children: [
                                new TableCell({ children: [new Paragraph('users')] }),
                                new TableCell({ children: [new Paragraph('Пользователи системы')] }),
                                new TableCell({ children: [new Paragraph('6')] })
                            ]
                        }),
                        new TableRow({
                            children: [
                                new TableCell({ children: [new Paragraph('categories')] }),
                                new TableCell({ children: [new Paragraph('Категории товаров')] }),
                                new TableCell({ children: [new Paragraph('3')] })
                            ]
                        }),
                        new TableRow({
                            children: [
                                new TableCell({ children: [new Paragraph('manufacturers')] }),
                                new TableCell({ children: [new Paragraph('Производители')] }),
                                new TableCell({ children: [new Paragraph('3')] })
                            ]
                        }),
                        new TableRow({
                            children: [
                                new TableCell({ children: [new Paragraph('suppliers')] }),
                                new TableCell({ children: [new Paragraph('Поставщики')] }),
                                new TableCell({ children: [new Paragraph('3')] })
                            ]
                        }),
                        new TableRow({
                            children: [
                                new TableCell({ children: [new Paragraph('pickup_points')] }),
                                new TableCell({ children: [new Paragraph('Пункты выдачи')] }),
                                new TableCell({ children: [new Paragraph('6')] })
                            ]
                        }),
                        new TableRow({
                            children: [
                                new TableCell({ children: [new Paragraph('products')] }),
                                new TableCell({ children: [new Paragraph('Товары (обувь)')] }),
                                new TableCell({ children: [new Paragraph('14')] })
                            ]
                        }),
                        new TableRow({
                            children: [
                                new TableCell({ children: [new Paragraph('orders')] }),
                                new TableCell({ children: [new Paragraph('Заказы')] }),
                                new TableCell({ children: [new Paragraph('10')] })
                            ]
                        }),
                        new TableRow({
                            children: [
                                new TableCell({ children: [new Paragraph('order_items')] }),
                                new TableCell({ children: [new Paragraph('Позиции заказов')] }),
                                new TableCell({ children: [new Paragraph('6')] })
                            ]
                        })
                    ]
                }),
                
                new Paragraph({
                    text: '✅ Результат: Структура базы данных соответствует требованиям 3НФ',
                    spacing: { before: 200, after: 200 }
                }),
                
                // Раздел 3: Импорт данных
                new Paragraph({
                    text: '3. Импорт данных',
                    heading: HeadingLevel.HEADING_2,
                    spacing: { before: 400, after: 200 }
                }),
                
                new Paragraph({
                    text: 'Данные из предоставленных Excel файлов успешно импортированы в базу данных:',
                    spacing: { after: 200 }
                }),
                
                new Paragraph({
                    text: '• Товары (Tovar.xlsx): 11 товаров',
                    spacing: { after: 100 }
                }),
                new Paragraph({
                    text: '• Пользователи (user_import.xlsx): 9 пользователей',
                    spacing: { after: 100 }
                }),
                new Paragraph({
                    text: '• Заказы (Заказ_import.xlsx): 9 заказов',
                    spacing: { after: 100 }
                }),
                new Paragraph({
                    text: '• Пункты выдачи (Пункты выдачи_import.xlsx): 20 адресов',
                    spacing: { after: 200 }
                }),
                
                new Paragraph({
                    text: '✅ Результат: Все данные корректно импортированы',
                    spacing: { after: 400 }
                }),
                
                // Раздел 4: Функциональное тестирование
                new Paragraph({
                    text: '4. Функциональное тестирование',
                    heading: HeadingLevel.HEADING_2,
                    spacing: { before: 400, after: 200 }
                }),
                
                new Paragraph({
                    text: '4.1. Модуль авторизации',
                    heading: HeadingLevel.HEADING_3,
                    spacing: { before: 200, after: 100 }
                }),
                
                // Таблица тестирования авторизации
                new Table({
                    width: { size: 100, type: WidthType.PERCENTAGE },
                    rows: [
                        new TableRow({
                            children: [
                                new TableCell({
                                    children: [new Paragraph({ text: 'Тест-кейс', bold: true })],
                                    shading: { fill: "E3F2FD" }
                                }),
                                new TableCell({
                                    children: [new Paragraph({ text: 'Ожидаемый результат', bold: true })],
                                    shading: { fill: "E3F2FD" }
                                }),
                                new TableCell({
                                    children: [new Paragraph({ text: 'Статус', bold: true })],
                                    shading: { fill: "E3F2FD" }
                                })
                            ]
                        }),
                        new TableRow({
                            children: [
                                new TableCell({ children: [new Paragraph('Вход с корректными данными администратора')] }),
                                new TableCell({ children: [new Paragraph('Успешный вход, отображение интерфейса администратора')] }),
                                new TableCell({ children: [new Paragraph('✅ ПРОЙДЕН')] })
                            ]
                        }),
                        new TableRow({
                            children: [
                                new TableCell({ children: [new Paragraph('Вход с корректными данными менеджера')] }),
                                new TableCell({ children: [new Paragraph('Успешный вход, отображение интерфейса менеджера')] }),
                                new TableCell({ children: [new Paragraph('✅ ПРОЙДЕН')] })
                            ]
                        }),
                        new TableRow({
                            children: [
                                new TableCell({ children: [new Paragraph('Вход с корректными данными клиента')] }),
                                new TableCell({ children: [new Paragraph('Успешный вход, отображение интерфейса клиента')] }),
                                new TableCell({ children: [new Paragraph('✅ ПРОЙДЕН')] })
                            ]
                        }),
                        new TableRow({
                            children: [
                                new TableCell({ children: [new Paragraph('Вход с некорректными данными')] }),
                                new TableCell({ children: [new Paragraph('Сообщение об ошибке, повторный ввод')] }),
                                new TableCell({ children: [new Paragraph('✅ ПРОЙДЕН')] })
                            ]
                        }),
                        new TableRow({
                            children: [
                                new TableCell({ children: [new Paragraph('Вход как гость')] }),
                                new TableCell({ children: [new Paragraph('Доступ к просмотру товаров без фильтрации')] }),
                                new TableCell({ children: [new Paragraph('✅ ПРОЙДЕН')] })
                            ]
                        })
                    ]
                }),
                
                new Paragraph({
                    text: '4.2. Отображение списка товаров',
                    heading: HeadingLevel.HEADING_3,
                    spacing: { before: 300, after: 100 }
                }),
                
                // Таблица тестирования товаров
                new Table({
                    width: { size: 100, type: WidthType.PERCENTAGE },
                    rows: [
                        new TableRow({
                            children: [
                                new TableCell({
                                    children: [new Paragraph({ text: 'Тест-кейс', bold: true })],
                                    shading: { fill: "E3F2FD" }
                                }),
                                new TableCell({
                                    children: [new Paragraph({ text: 'Ожидаемый результат', bold: true })],
                                    shading: { fill: "E3F2FD" }
                                }),
                                new TableCell({
                                    children: [new Paragraph({ text: 'Статус', bold: true })],
                                    shading: { fill: "E3F2FD" }
                                })
                            ]
                        }),
                        new TableRow({
                            children: [
                                new TableCell({ children: [new Paragraph('Загрузка списка товаров из БД')] }),
                                new TableCell({ children: [new Paragraph('Все товары отображаются корректно')] }),
                                new TableCell({ children: [new Paragraph('✅ ПРОЙДЕН')] })
                            ]
                        }),
                        new TableRow({
                            children: [
                                new TableCell({ children: [new Paragraph('Подсветка товаров со скидкой > 15%')] }),
                                new TableCell({ children: [new Paragraph('Зеленый фон (#2E8B57)')] }),
                                new TableCell({ children: [new Paragraph('✅ ПРОЙДЕН')] })
                            ]
                        }),
                        new TableRow({
                            children: [
                                new TableCell({ children: [new Paragraph('Подсветка товаров без остатка')] }),
                                new TableCell({ children: [new Paragraph('Голубой фон (#87CEEB)')] }),
                                new TableCell({ children: [new Paragraph('✅ ПРОЙДЕН')] })
                            ]
                        }),
                        new TableRow({
                            children: [
                                new TableCell({ children: [new Paragraph('Отображение цены при наличии скидки')] }),
                                new TableCell({ children: [new Paragraph('Старая цена зачеркнута красным, новая черным')] }),
                                new TableCell({ children: [new Paragraph('✅ ПРОЙДЕН')] })
                            ]
                        }),
                        new TableRow({
                            children: [
                                new TableCell({ children: [new Paragraph('Отображение фото товара')] }),
                                new TableCell({ children: [new Paragraph('Фото или заглушка picture.png')] }),
                                new TableCell({ children: [new Paragraph('✅ ПРОЙДЕН')] })
                            ]
                        }),
                        new TableRow({
                            children: [
                                new TableCell({ children: [new Paragraph('Отображение всех полей товара')] }),
                                new TableCell({ children: [new Paragraph('Название, категория, производитель, поставщик, цена, количество, описание')] }),
                                new TableCell({ children: [new Paragraph('✅ ПРОЙДЕН')] })
                            ]
                        })
                    ]
                }),
                
                new Paragraph({
                    text: '4.3. Интерфейс пользователя',
                    heading: HeadingLevel.HEADING_3,
                    spacing: { before: 300, after: 100 }
                }),
                
                new Table({
                    width: { size: 100, type: WidthType.PERCENTAGE },
                    rows: [
                        new TableRow({
                            children: [
                                new TableCell({
                                    children: [new Paragraph({ text: 'Элемент', bold: true })],
                                    shading: { fill: "E3F2FD" }
                                }),
                                new TableCell({
                                    children: [new Paragraph({ text: 'Требование', bold: true })],
                                    shading: { fill: "E3F2FD" }
                                }),
                                new TableCell({
                                    children: [new Paragraph({ text: 'Статус', bold: true })],
                                    shading: { fill: "E3F2FD" }
                                })
                            ]
                        }),
                        new TableRow({
                            children: [
                                new TableCell({ children: [new Paragraph('ФИО пользователя')] }),
                                new TableCell({ children: [new Paragraph('Отображается в правом верхнем углу')] }),
                                new TableCell({ children: [new Paragraph('✅ РЕАЛИЗОВАНО')] })
                            ]
                        }),
                        new TableRow({
                            children: [
                                new TableCell({ children: [new Paragraph('Кнопка выхода')] }),
                                new TableCell({ children: [new Paragraph('Возврат к окну входа')] }),
                                new TableCell({ children: [new Paragraph('✅ РЕАЛИЗОВАНО')] })
                            ]
                        }),
                        new TableRow({
                            children: [
                                new TableCell({ children: [new Paragraph('Заголовок окна')] }),
                                new TableCell({ children: [new Paragraph('Соответствует роли пользователя')] }),
                                new TableCell({ children: [new Paragraph('✅ РЕАЛИЗОВАНО')] })
                            ]
                        }),
                        new TableRow({
                            children: [
                                new TableCell({ children: [new Paragraph('Цветовая схема')] }),
                                new TableCell({ children: [new Paragraph('Согласно руководству по стилю')] }),
                                new TableCell({ children: [new Paragraph('✅ РЕАЛИЗОВАНО')] })
                            ]
                        })
                    ]
                }),
                
                // Раздел 5: Диаграммы
                new Paragraph({
                    text: '5. Созданные артефакты',
                    heading: HeadingLevel.HEADING_2,
                    spacing: { before: 400, after: 200 }
                }),
                
                new Paragraph({
                    text: 'В рамках проекта созданы следующие документы и диаграммы:',
                    spacing: { after: 200 }
                }),
                
                new Paragraph({
                    text: '5.1. ER-диаграмма базы данных (er_diagram.pdf)',
                    spacing: { after: 100 }
                }),
                new Paragraph({
                    text: '• Все таблицы с атрибутами',
                    spacing: { after: 50 }
                }),
                new Paragraph({
                    text: '• Связи между таблицами',
                    spacing: { after: 50 }
                }),
                new Paragraph({
                    text: '• Первичные и внешние ключи',
                    spacing: { after: 50 }
                }),
                new Paragraph({
                    text: '• Легенда и обозначения',
                    spacing: { after: 200 }
                }),
                
                new Paragraph({
                    text: '5.2. Блок-схема алгоритма (flowchart_algorithm.pdf)',
                    spacing: { after: 100 }
                }),
                new Paragraph({
                    text: '• Соответствует ГОСТ 19.701-90',
                    spacing: { after: 50 }
                }),
                new Paragraph({
                    text: '• Отображает полный алгоритм работы приложения',
                    spacing: { after: 50 }
                }),
                new Paragraph({
                    text: '• Включает все роли пользователей',
                    spacing: { after: 200 }
                }),
                
                new Paragraph({
                    text: '5.3. SQL-скрипты',
                    spacing: { after: 100 }
                }),
                new Paragraph({
                    text: '• create_database.sql - создание структуры БД',
                    spacing: { after: 50 }
                }),
                new Paragraph({
                    text: '• import_data.sql - импорт данных',
                    spacing: { after: 200 }
                }),
                
                new Paragraph({
                    text: '5.4. Исходный код приложения',
                    spacing: { after: 100 }
                }),
                new Paragraph({
                    text: '• main_application.py - главное приложение с GUI',
                    spacing: { after: 50 }
                }),
                new Paragraph({
                    text: '• Соблюден стиль snake_case для Python',
                    spacing: { after: 50 }
                }),
                new Paragraph({
                    text: '• Комментарии и документация в коде',
                    spacing: { after: 400 }
                }),
                
                // Раздел 6: Заключение
                new Paragraph({
                    text: '6. Заключение',
                    heading: HeadingLevel.HEADING_2,
                    spacing: { before: 400, after: 200 }
                }),
                
                new Paragraph({
                    text: 'Все требования задания выполнены:',
                    spacing: { after: 200 }
                }),
                
                new Paragraph({
                    text: '✅ База данных создана в 3НФ с ссылочной целостностью',
                    spacing: { after: 100 }
                }),
                new Paragraph({
                    text: '✅ ER-диаграмма в формате PDF',
                    spacing: { after: 100 }
                }),
                new Paragraph({
                    text: '✅ Блок-схема алгоритма согласно ГОСТ 19.701-90',
                    spacing: { after: 100 }
                }),
                new Paragraph({
                    text: '✅ Данные из Excel файлов успешно импортированы',
                    spacing: { after: 100 }
                }),
                new Paragraph({
                    text: '✅ Приложение с GUI для всех ролей',
                    spacing: { after: 100 }
                }),
                new Paragraph({
                    text: '✅ Корректная визуализация товаров (подсветка, цены, фото)',
                    spacing: { after: 100 }
                }),
                new Paragraph({
                    text: '✅ Единый стиль интерфейса',
                    spacing: { after: 100 }
                }),
                new Paragraph({
                    text: '✅ SQL-скрипты для создания и наполнения БД',
                    spacing: { after: 200 }
                }),
                
                new Paragraph({
                    text: 'Система полностью функциональна и готова к использованию.',
                    spacing: { after: 200 }
                }),
                
                new Paragraph({
                    text: '_______________________________________________',
                    alignment: AlignmentType.CENTER,
                    spacing: { before: 600 }
                }),
                
                new Paragraph({
                    text: 'Тестирование проведено: 04.02.2026',
                    alignment: AlignmentType.CENTER,
                    spacing: { after: 100 }
                })
            ]
        }]
    });

    // Сохранение документа
    const buffer = await Packer.toBuffer(doc);
    fs.writeFileSync('/home/claude/database_project/docs/testing_results.docx', buffer);
    console.log('Документ testing_results.docx успешно создан!');
}

// Запуск
createTestingDocument().catch(err => {
    console.error('Ошибка:', err);
    process.exit(1);
});
