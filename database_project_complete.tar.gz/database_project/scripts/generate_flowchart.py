#!/usr/bin/env python3
"""
Скрипт для создания блок-схемы алгоритма работы приложения
Согласно ГОСТ 19.701-90
"""

from graphviz import Digraph

def create_flowchart():
    """Создание блок-схемы алгоритма приложения"""
    
    dot = Digraph(comment='Блок-схема алгоритма работы приложения',
                  format='pdf')
    
    # Настройки
    dot.attr(rankdir='TB', splines='ortho', nodesep='0.5', ranksep='0.7')
    dot.attr('node', fontname='Arial', fontsize='10')
    dot.attr('edge', fontname='Arial', fontsize='9')
    
    # Терминатор (овал) - начало
    dot.node('start', 'Начало', shape='ellipse', style='filled', 
             fillcolor='#E8F5E9', width='1.5', height='0.5')
    
    # Процесс (прямоугольник)
    dot.node('init', 'Инициализация\nприложения', shape='box', style='filled',
             fillcolor='#E3F2FD', width='2', height='0.8')
    
    dot.node('show_login', 'Отображение\nокна входа', shape='box', style='filled',
             fillcolor='#E3F2FD', width='2', height='0.8')
    
    # Условие (ромб)
    dot.node('check_guest', 'Вход как\nгость?', shape='diamond', style='filled',
             fillcolor='#FFF9C4', width='2', height='1')
    
    # Процессы для гостя
    dot.node('guest_mode', 'Режим гостя:\nпросмотр товаров\n(без фильтров)', 
             shape='box', style='filled', fillcolor='#E3F2FD', width='2.5', height='1')
    
    # Ввод данных (параллелограмм)
    dot.node('input_creds', 'Ввод логина\nи пароля', shape='parallelogram',
             style='filled', fillcolor='#FCE4EC', width='2', height='0.8',
             skew='0.3')
    
    # Процесс
    dot.node('validate', 'Проверка\nучетных данных\nв БД', shape='box',
             style='filled', fillcolor='#E3F2FD', width='2', height='1')
    
    # Условие
    dot.node('check_valid', 'Данные\nверны?', shape='diamond', style='filled',
             fillcolor='#FFF9C4', width='2', height='1')
    
    # Процесс
    dot.node('error_msg', 'Вывод сообщения\nоб ошибке', shape='box',
             style='filled', fillcolor='#FFEBEE', width='2', height='0.8')
    
    # Процесс
    dot.node('get_role', 'Определение\nроли пользователя', shape='box',
             style='filled', fillcolor='#E3F2FD', width='2', height='0.8')
    
    # Условие с множественным выбором
    dot.node('check_role', 'Роль?', shape='diamond', style='filled',
             fillcolor='#FFF9C4', width='1.5', height='1')
    
    # Процессы для разных ролей
    dot.node('admin_ui', 'Интерфейс\nадминистратора:\n- Все операции\n- CRUD товаров\n- CRUD заказов',
             shape='box', style='filled', fillcolor='#F3E5F5', width='2.5', height='1.5')
    
    dot.node('manager_ui', 'Интерфейс\nменеджера:\n- Просмотр товаров\n  (фильтры, поиск)\n- Просмотр заказов',
             shape='box', style='filled', fillcolor='#F3E5F5', width='2.5', height='1.5')
    
    dot.node('client_ui', 'Интерфейс\nклиента:\n- Просмотр товаров\n  (без фильтров)',
             shape='box', style='filled', fillcolor='#F3E5F5', width='2.5', height='1.2')
    
    # Процесс загрузки данных
    dot.node('load_products', 'Загрузка списка\nтоваров из БД', shape='box',
             style='filled', fillcolor='#E3F2FD', width='2', height='0.8')
    
    # Процесс отображения
    dot.node('display_products', 'Отображение товаров:\n- Фото/заглушка\n- Название, категория\n- Цена, скидка\n- Количество на складе',
             shape='box', style='filled', fillcolor='#E3F2FD', width='2.8', height='1.5')
    
    # Процесс применения стилей
    dot.node('apply_styles', 'Применение стилей:\n- Скидка > 15%: зеленый\n- Нет на складе: голубой\n- Зачеркнутая цена при скидке',
             shape='box', style='filled', fillcolor='#E3F2FD', width='3', height='1.5')
    
    # Условие
    dot.node('check_action', 'Действие\nпользователя?', shape='diamond',
             style='filled', fillcolor='#FFF9C4', width='2', height='1')
    
    # Процесс
    dot.node('perform_action', 'Выполнение действия\n(в зависимости от роли)',
             shape='box', style='filled', fillcolor='#E3F2FD', width='2.5', height='0.8')
    
    # Условие
    dot.node('check_exit', 'Выход?', shape='diamond', style='filled',
             fillcolor='#FFF9C4', width='1.5', height='0.8')
    
    # Терминатор - конец
    dot.node('end', 'Конец', shape='ellipse', style='filled',
             fillcolor='#FFEBEE', width='1.5', height='0.5')
    
    # Связи
    dot.edge('start', 'init')
    dot.edge('init', 'show_login')
    dot.edge('show_login', 'check_guest')
    dot.edge('check_guest', 'guest_mode', label='Да')
    dot.edge('check_guest', 'input_creds', label='Нет')
    dot.edge('input_creds', 'validate')
    dot.edge('validate', 'check_valid')
    dot.edge('check_valid', 'error_msg', label='Нет')
    dot.edge('error_msg', 'show_login')
    dot.edge('check_valid', 'get_role', label='Да')
    dot.edge('get_role', 'check_role')
    dot.edge('check_role', 'admin_ui', label='Администратор')
    dot.edge('check_role', 'manager_ui', label='Менеджер')
    dot.edge('check_role', 'client_ui', label='Клиент')
    dot.edge('admin_ui', 'load_products')
    dot.edge('manager_ui', 'load_products')
    dot.edge('client_ui', 'load_products')
    dot.edge('guest_mode', 'load_products')
    dot.edge('load_products', 'display_products')
    dot.edge('display_products', 'apply_styles')
    dot.edge('apply_styles', 'check_action')
    dot.edge('check_action', 'perform_action', label='Есть действие')
    dot.edge('perform_action', 'check_action')
    dot.edge('check_action', 'check_exit', label='Нет действия')
    dot.edge('check_exit', 'check_action', label='Нет')
    dot.edge('check_exit', 'end', label='Да')
    
    # Заголовок
    dot.attr(label='\\n\\nБлок-схема алгоритма работы приложения\\n'
                  'ООО «Обувь» - Система управления магазином обуви\\n'
                  'ГОСТ 19.701-90\\n'
                  'Дата: 04.02.2026',
            labelloc='t', fontsize='14', fontname='Arial Bold')
    
    return dot

if __name__ == '__main__':
    print("Создание блок-схемы алгоритма...")
    flowchart = create_flowchart()
    
    # Сохраняем
    output_path = '/home/claude/database_project/diagrams/flowchart_algorithm'
    flowchart.render(output_path, cleanup=True)
    print(f"Блок-схема успешно создана: {output_path}.pdf")
