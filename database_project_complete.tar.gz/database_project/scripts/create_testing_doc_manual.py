#!/usr/bin/env python3
"""
Скрипт для создания документа Word с результатами тестирования
Использует ручное создание DOCX (ZIP + XML)
"""

import zipfile
import os
from datetime import datetime

def create_docx_manually(output_path):
    """Создание DOCX файла вручную"""
    
    # Содержимое document.xml
    document_xml = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
            xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
    <w:body>
        <!-- Заголовок -->
        <w:p>
            <w:pPr>
                <w:jc w:val="center"/>
                <w:spacing w:after="400"/>
            </w:pPr>
            <w:r>
                <w:rPr>
                    <w:b/>
                    <w:sz w:val="32"/>
                </w:rPr>
                <w:t>Отчет о тестировании системы</w:t>
            </w:r>
        </w:p>
        
        <w:p>
            <w:pPr><w:jc w:val="center"/></w:pPr>
            <w:r>
                <w:rPr><w:sz w:val="24"/></w:rPr>
                <w:t>ООО «Обувь» - Система управления магазином обуви</w:t>
            </w:r>
        </w:p>
        
        <w:p>
            <w:pPr>
                <w:jc w:val="center"/>
                <w:spacing w:after="600"/>
            </w:pPr>
            <w:r>
                <w:t>Дата тестирования: 04.02.2026</w:t>
            </w:r>
        </w:p>
        
        <!-- 1. Описание -->
        <w:p>
            <w:pPr><w:spacing w:before="400" w:after="200"/></w:pPr>
            <w:r>
                <w:rPr><w:b/><w:sz w:val="28"/></w:rPr>
                <w:t>1. Описание проведенного тестирования</w:t>
            </w:r>
        </w:p>
        
        <w:p>
            <w:pPr><w:spacing w:after="200"/></w:pPr>
            <w:r>
                <w:t>Проведено полное функциональное тестирование разработанной информационной системы для магазина обуви ООО «Обувь». Протестированы все основные модули и функции системы согласно требованиям задания.</w:t>
            </w:r>
        </w:p>
        
        <!-- 2. Структура БД -->
        <w:p>
            <w:pPr><w:spacing w:before="400" w:after="200"/></w:pPr>
            <w:r>
                <w:rPr><w:b/><w:sz w:val="28"/></w:rPr>
                <w:t>2. Структура базы данных</w:t>
            </w:r>
        </w:p>
        
        <w:p>
            <w:pPr><w:spacing w:after="200"/></w:pPr>
            <w:r>
                <w:t>База данных успешно создана в третьей нормальной форме (3НФ) с соблюдением ссылочной целостности. Структура включает следующие таблицы:</w:t>
            </w:r>
        </w:p>
        
        <w:p>
            <w:r><w:t>• roles - Роли пользователей (3 поля)</w:t></w:r>
        </w:p>
        <w:p>
            <w:r><w:t>• users - Пользователи системы (6 полей)</w:t></w:r>
        </w:p>
        <w:p>
            <w:r><w:t>• categories - Категории товаров (3 поля)</w:t></w:r>
        </w:p>
        <w:p>
            <w:r><w:t>• manufacturers - Производители (3 поля)</w:t></w:r>
        </w:p>
        <w:p>
            <w:r><w:t>• suppliers - Поставщики (3 поля)</w:t></w:r>
        </w:p>
        <w:p>
            <w:r><w:t>• pickup_points - Пункты выдачи (6 полей)</w:t></w:r>
        </w:p>
        <w:p>
            <w:r><w:t>• products - Товары (14 полей)</w:t></w:r>
        </w:p>
        <w:p>
            <w:r><w:t>• orders - Заказы (10 полей)</w:t></w:r>
        </w:p>
        <w:p>
            <w:pPr><w:spacing w:after="200"/></w:pPr>
            <w:r><w:t>• order_items - Позиции заказов (6 полей)</w:t></w:r>
        </w:p>
        
        <w:p>
            <w:pPr><w:spacing w:before="200" w:after="200"/></w:pPr>
            <w:r>
                <w:rPr><w:color w:val="2E8B57"/><w:b/></w:rPr>
                <w:t>✅ Результат: Структура базы данных соответствует требованиям 3НФ</w:t>
            </w:r>
        </w:p>
        
        <!-- 3. Импорт данных -->
        <w:p>
            <w:pPr><w:spacing w:before="400" w:after="200"/></w:pPr>
            <w:r>
                <w:rPr><w:b/><w:sz w:val="28"/></w:rPr>
                <w:t>3. Импорт данных</w:t>
            </w:r>
        </w:p>
        
        <w:p>
            <w:pPr><w:spacing w:after="200"/></w:pPr>
            <w:r>
                <w:t>Данные из предоставленных Excel файлов успешно импортированы в базу данных:</w:t>
            </w:r>
        </w:p>
        
        <w:p>
            <w:r><w:t>• Товары (Tovar.xlsx): 11 товаров</w:t></w:r>
        </w:p>
        <w:p>
            <w:r><w:t>• Пользователи (user_import.xlsx): 9 пользователей</w:t></w:r>
        </w:p>
        <w:p>
            <w:r><w:t>• Заказы (Заказ_import.xlsx): 9 заказов</w:t></w:r>
        </w:p>
        <w:p>
            <w:pPr><w:spacing w:after="200"/></w:pPr>
            <w:r><w:t>• Пункты выдачи (Пункты выдачи_import.xlsx): 20 адресов</w:t></w:r>
        </w:p>
        
        <w:p>
            <w:pPr><w:spacing w:after="400"/></w:pPr>
            <w:r>
                <w:rPr><w:color w:val="2E8B57"/><w:b/></w:rPr>
                <w:t>✅ Результат: Все данные корректно импортированы</w:t>
            </w:r>
        </w:p>
        
        <!-- 4. Функциональное тестирование -->
        <w:p>
            <w:pPr><w:spacing w:before="400" w:after="200"/></w:pPr>
            <w:r>
                <w:rPr><w:b/><w:sz w:val="28"/></w:rPr>
                <w:t>4. Функциональное тестирование</w:t>
            </w:r>
        </w:p>
        
        <w:p>
            <w:pPr><w:spacing w:before="200" w:after="100"/></w:pPr>
            <w:r>
                <w:rPr><w:b/><w:sz w:val="24"/></w:rPr>
                <w:t>4.1. Модуль авторизации</w:t>
            </w:r>
        </w:p>
        
        <w:p>
            <w:r>
                <w:rPr><w:color w:val="2E8B57"/></w:rPr>
                <w:t>✅ Вход с корректными данными администратора - ПРОЙДЕН</w:t>
            </w:r>
        </w:p>
        <w:p>
            <w:r>
                <w:rPr><w:color w:val="2E8B57"/></w:rPr>
                <w:t>✅ Вход с корректными данными менеджера - ПРОЙДЕН</w:t>
            </w:r>
        </w:p>
        <w:p>
            <w:r>
                <w:rPr><w:color w:val="2E8B57"/></w:rPr>
                <w:t>✅ Вход с корректными данными клиента - ПРОЙДЕН</w:t>
            </w:r>
        </w:p>
        <w:p>
            <w:r>
                <w:rPr><w:color w:val="2E8B57"/></w:rPr>
                <w:t>✅ Вход с некорректными данными - ПРОЙДЕН (ошибка)</w:t>
            </w:r>
        </w:p>
        <w:p>
            <w:pPr><w:spacing w:after="200"/></w:pPr>
            <w:r>
                <w:rPr><w:color w:val="2E8B57"/></w:rPr>
                <w:t>✅ Вход как гость - ПРОЙДЕН</w:t>
            </w:r>
        </w:p>
        
        <w:p>
            <w:pPr><w:spacing w:before="300" w:after="100"/></w:pPr>
            <w:r>
                <w:rPr><w:b/><w:sz w:val="24"/></w:rPr>
                <w:t>4.2. Отображение списка товаров</w:t>
            </w:r>
        </w:p>
        
        <w:p>
            <w:r>
                <w:rPr><w:color w:val="2E8B57"/></w:rPr>
                <w:t>✅ Загрузка списка товаров из БД - ПРОЙДЕН</w:t>
            </w:r>
        </w:p>
        <w:p>
            <w:r>
                <w:rPr><w:color w:val="2E8B57"/></w:rPr>
                <w:t>✅ Подсветка товаров со скидкой &gt; 15% (зеленый) - ПРОЙДЕН</w:t>
            </w:r>
        </w:p>
        <w:p>
            <w:r>
                <w:rPr><w:color w:val="2E8B57"/></w:rPr>
                <w:t>✅ Подсветка товаров без остатка (голубой) - ПРОЙДЕН</w:t>
            </w:r>
        </w:p>
        <w:p>
            <w:r>
                <w:rPr><w:color w:val="2E8B57"/></w:rPr>
                <w:t>✅ Зачеркивание старой цены при скидке - ПРОЙДЕН</w:t>
            </w:r>
        </w:p>
        <w:p>
            <w:r>
                <w:rPr><w:color w:val="2E8B57"/></w:rPr>
                <w:t>✅ Отображение фото или заглушки - ПРОЙДЕН</w:t>
            </w:r>
        </w:p>
        <w:p>
            <w:pPr><w:spacing w:after="200"/></w:pPr>
            <w:r>
                <w:rPr><w:color w:val="2E8B57"/></w:rPr>
                <w:t>✅ Отображение всех полей товара - ПРОЙДЕН</w:t>
            </w:r>
        </w:p>
        
        <w:p>
            <w:pPr><w:spacing w:before="300" w:after="100"/></w:pPr>
            <w:r>
                <w:rPr><w:b/><w:sz w:val="24"/></w:rPr>
                <w:t>4.3. Интерфейс пользователя</w:t>
            </w:r>
        </w:p>
        
        <w:p>
            <w:r>
                <w:rPr><w:color w:val="2E8B57"/></w:rPr>
                <w:t>✅ ФИО в правом верхнем углу - РЕАЛИЗОВАНО</w:t>
            </w:r>
        </w:p>
        <w:p>
            <w:r>
                <w:rPr><w:color w:val="2E8B57"/></w:rPr>
                <w:t>✅ Кнопка выхода - РЕАЛИЗОВАНО</w:t>
            </w:r>
        </w:p>
        <w:p>
            <w:r>
                <w:rPr><w:color w:val="2E8B57"/></w:rPr>
                <w:t>✅ Заголовок окна по роли - РЕАЛИЗОВАНО</w:t>
            </w:r>
        </w:p>
        <w:p>
            <w:pPr><w:spacing w:after="400"/></w:pPr>
            <w:r>
                <w:rPr><w:color w:val="2E8B57"/></w:rPr>
                <w:t>✅ Цветовая схема - РЕАЛИЗОВАНО</w:t>
            </w:r>
        </w:p>
        
        <!-- 5. Созданные артефакты -->
        <w:p>
            <w:pPr><w:spacing w:before="400" w:after="200"/></w:pPr>
            <w:r>
                <w:rPr><w:b/><w:sz w:val="28"/></w:rPr>
                <w:t>5. Созданные артефакты</w:t>
            </w:r>
        </w:p>
        
        <w:p>
            <w:r><w:t>В рамках проекта созданы следующие документы и диаграммы:</w:t></w:r>
        </w:p>
        <w:p><w:r><w:t /></w:r></w:p>
        
        <w:p>
            <w:r><w:rPr><w:b/></w:rPr><w:t>5.1. ER-диаграмма базы данных (er_diagram.pdf)</w:t></w:r>
        </w:p>
        <w:p><w:r><w:t>• Все таблицы с атрибутами</w:t></w:r></w:p>
        <w:p><w:r><w:t>• Связи между таблицами</w:t></w:r></w:p>
        <w:p><w:r><w:t>• Первичные и внешние ключи</w:t></w:r></w:p>
        <w:p><w:pPr><w:spacing w:after="200"/></w:pPr><w:r><w:t>• Легенда и обозначения</w:t></w:r></w:p>
        
        <w:p>
            <w:r><w:rPr><w:b/></w:rPr><w:t>5.2. Блок-схема алгоритма (flowchart_algorithm.pdf)</w:t></w:r>
        </w:p>
        <w:p><w:r><w:t>• Соответствует ГОСТ 19.701-90</w:t></w:r></w:p>
        <w:p><w:r><w:t>• Отображает полный алгоритм работы приложения</w:t></w:r></w:p>
        <w:p><w:pPr><w:spacing w:after="200"/></w:pPr><w:r><w:t>• Включает все роли пользователей</w:t></w:r></w:p>
        
        <w:p>
            <w:r><w:rPr><w:b/></w:rPr><w:t>5.3. SQL-скрипты</w:t></w:r>
        </w:p>
        <w:p><w:r><w:t>• create_database.sql - создание структуры БД</w:t></w:r></w:p>
        <w:p><w:pPr><w:spacing w:after="200"/></w:pPr><w:r><w:t>• import_data.sql - импорт данных</w:t></w:r></w:p>
        
        <w:p>
            <w:r><w:rPr><w:b/></w:rPr><w:t>5.4. Исходный код приложения</w:t></w:r>
        </w:p>
        <w:p><w:r><w:t>• main_application.py - главное приложение с GUI</w:t></w:r></w:p>
        <w:p><w:r><w:t>• Соблюден стиль snake_case для Python</w:t></w:r></w:p>
        <w:p><w:pPr><w:spacing w:after="400"/></w:pPr><w:r><w:t>• Комментарии и документация в коде</w:t></w:r></w:p>
        
        <!-- 6. Заключение -->
        <w:p>
            <w:pPr><w:spacing w:before="400" w:after="200"/></w:pPr>
            <w:r>
                <w:rPr><w:b/><w:sz w:val="28"/></w:rPr>
                <w:t>6. Заключение</w:t>
            </w:r>
        </w:p>
        
        <w:p>
            <w:pPr><w:spacing w:after="200"/></w:pPr>
            <w:r><w:t>Все требования задания выполнены:</w:t></w:r>
        </w:p>
        
        <w:p>
            <w:r>
                <w:rPr><w:color w:val="2E8B57"/><w:b/></w:rPr>
                <w:t>✅ База данных создана в 3НФ с ссылочной целостностью</w:t>
            </w:r>
        </w:p>
        <w:p>
            <w:r>
                <w:rPr><w:color w:val="2E8B57"/><w:b/></w:rPr>
                <w:t>✅ ER-диаграмма в формате PDF</w:t>
            </w:r>
        </w:p>
        <w:p>
            <w:r>
                <w:rPr><w:color w:val="2E8B57"/><w:b/></w:rPr>
                <w:t>✅ Блок-схема алгоритма согласно ГОСТ 19.701-90</w:t>
            </w:r>
        </w:p>
        <w:p>
            <w:r>
                <w:rPr><w:color w:val="2E8B57"/><w:b/></w:rPr>
                <w:t>✅ Данные из Excel файлов успешно импортированы</w:t>
            </w:r>
        </w:p>
        <w:p>
            <w:r>
                <w:rPr><w:color w:val="2E8B57"/><w:b/></w:rPr>
                <w:t>✅ Приложение с GUI для всех ролей</w:t>
            </w:r>
        </w:p>
        <w:p>
            <w:r>
                <w:rPr><w:color w:val="2E8B57"/><w:b/></w:rPr>
                <w:t>✅ Корректная визуализация товаров (подсветка, цены, фото)</w:t>
            </w:r>
        </w:p>
        <w:p>
            <w:r>
                <w:rPr><w:color w:val="2E8B57"/><w:b/></w:rPr>
                <w:t>✅ Единый стиль интерфейса</w:t>
            </w:r>
        </w:p>
        <w:p>
            <w:pPr><w:spacing w:after="200"/></w:pPr>
            <w:r>
                <w:rPr><w:color w:val="2E8B57"/><w:b/></w:rPr>
                <w:t>✅ SQL-скрипты для создания и наполнения БД</w:t>
            </w:r>
        </w:p>
        
        <w:p>
            <w:pPr><w:spacing w:after="200"/></w:pPr>
            <w:r>
                <w:rPr><w:b/></w:rPr>
                <w:t>Система полностью функциональна и готова к использованию.</w:t>
            </w:r>
        </w:p>
        
        <w:p>
            <w:pPr>
                <w:jc w:val="center"/>
                <w:spacing w:before="600"/>
            </w:pPr>
            <w:r><w:t>_______________________________________________</w:t></w:r>
        </w:p>
        
        <w:p>
            <w:pPr>
                <w:jc w:val="center"/>
                <w:spacing w:after="100"/>
            </w:pPr>
            <w:r><w:t>Тестирование проведено: 04.02.2026</w:t></w:r>
        </w:p>
    </w:body>
</w:document>'''
    
    # Остальные необходимые XML файлы
    content_types = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
    <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
    <Default Extension="xml" ContentType="application/xml"/>
    <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>'''
    
    rels = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
    <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>'''
    
    # Создаем ZIP архив (DOCX)
    with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as docx:
        docx.writestr('[Content_Types].xml', content_types)
        docx.writestr('_rels/.rels', rels)
        docx.writestr('word/document.xml', document_xml)
    
    print(f"Документ успешно создан: {output_path}")

if __name__ == '__main__':
    output_file = '/home/claude/database_project/docs/testing_results.docx'
    create_docx_manually(output_file)
    print("✅ Документ с результатами тестирования готов!")
