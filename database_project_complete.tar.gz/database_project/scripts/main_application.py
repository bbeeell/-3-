#!/usr/bin/env python3
"""
Приложение для управления магазином обуви ООО «Обувь»
Модуль: Главное приложение
Стиль кода: snake_case (Python)
"""

import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
import os
from pathlib import Path

# Константы для цветовой схемы (из руководства по стилю)
COLOR_PRIMARY = "#4A90E2"
COLOR_SUCCESS = "#2E8B57"
COLOR_INFO = "#87CEEB"
COLOR_DANGER = "#DC143C"
COLOR_BG = "#F5F5F5"
COLOR_TEXT = "#333333"

class DatabaseManager:
    """Менеджер для работы с базой данных"""
    
    def __init__(self, db_path='shop_database.db'):
        """Инициализация подключения к БД"""
        self.db_path = db_path
        self.connection = None
        self.create_database()
    
    def create_database(self):
        """Создание и инициализация базы данных SQLite"""
        self.connection = sqlite3.connect(self.db_path)
        cursor = self.connection.cursor()
        
        # Создание таблиц
        cursor.executescript('''
            -- Роли
            CREATE TABLE IF NOT EXISTS roles (
                role_id INTEGER PRIMARY KEY AUTOINCREMENT,
                role_name TEXT NOT NULL UNIQUE,
                description TEXT
            );
            
            -- Пользователи
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY AUTOINCREMENT,
                role_id INTEGER NOT NULL,
                full_name TEXT NOT NULL,
                login TEXT NOT NULL UNIQUE,
                password TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (role_id) REFERENCES roles(role_id)
            );
            
            -- Категории
            CREATE TABLE IF NOT EXISTS categories (
                category_id INTEGER PRIMARY KEY AUTOINCREMENT,
                category_name TEXT NOT NULL UNIQUE,
                description TEXT
            );
            
            -- Производители
            CREATE TABLE IF NOT EXISTS manufacturers (
                manufacturer_id INTEGER PRIMARY KEY AUTOINCREMENT,
                manufacturer_name TEXT NOT NULL UNIQUE,
                description TEXT
            );
            
            -- Поставщики
            CREATE TABLE IF NOT EXISTS suppliers (
                supplier_id INTEGER PRIMARY KEY AUTOINCREMENT,
                supplier_name TEXT NOT NULL UNIQUE,
                contact_info TEXT
            );
            
            -- Товары
            CREATE TABLE IF NOT EXISTS products (
                product_id INTEGER PRIMARY KEY AUTOINCREMENT,
                article TEXT NOT NULL UNIQUE,
                product_name TEXT NOT NULL,
                unit_of_measure TEXT NOT NULL,
                price REAL NOT NULL CHECK (price >= 0),
                supplier_id INTEGER NOT NULL,
                manufacturer_id INTEGER NOT NULL,
                category_id INTEGER NOT NULL,
                discount_percent INTEGER DEFAULT 0 CHECK (discount_percent >= 0 AND discount_percent <= 100),
                quantity_in_stock INTEGER DEFAULT 0 CHECK (quantity_in_stock >= 0),
                description TEXT,
                photo_filename TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id),
                FOREIGN KEY (manufacturer_id) REFERENCES manufacturers(manufacturer_id),
                FOREIGN KEY (category_id) REFERENCES categories(category_id)
            );
        ''')
        
        self.connection.commit()
    
    def import_initial_data(self):
        """Импорт начальных данных"""
        cursor = self.connection.cursor()
        
        # Проверяем, есть ли данные
        cursor.execute("SELECT COUNT(*) FROM roles")
        if cursor.fetchone()[0] > 0:
            return  # Данные уже импортированы
        
        # Роли
        cursor.executemany(
            "INSERT INTO roles (role_name, description) VALUES (?, ?)",
            [
                ('Администратор', 'Полный доступ к системе'),
                ('Менеджер', 'Просмотр товаров и заказов'),
                ('Авторизированный клиент', 'Просмотр товаров'),
                ('Гость', 'Ограниченный просмотр товаров')
            ]
        )
        
        # Пользователи
        cursor.executemany(
            "INSERT INTO users (role_id, full_name, login, password) VALUES (?, ?, ?, ?)",
            [
                (1, 'Никифорова Весения Николаевна', '94d5ous@gmail.com', 'uzWC67'),
                (1, 'Сазонов Руслан Германович', 'uth4iz@mail.com', '2L6KZG'),
                (2, 'Степанов Михаил Артёмович', '1diph5e@tutanota.com', '8ntwUp'),
                (2, 'Ворсин Петр Евгеньевич', 'tjde7c@yahoo.com', 'YOyhfR'),
                (3, 'Михайлюк Анна Вячеславовна', '5d4zbu@tutanota.com', 'rwVDh9'),
                (3, 'Ситдикова Елена Анатольевна', 'ptec8ym@yahoo.com', 'LdNyos')
            ]
        )
        
        # Категории
        cursor.executemany(
            "INSERT INTO categories (category_name) VALUES (?)",
            [('Женская обувь',), ('Мужская обувь',), ('Детская обувь',)]
        )
        
        # Производители
        cursor.executemany(
            "INSERT INTO manufacturers (manufacturer_name) VALUES (?)",
            [('Kari',), ('Marco Tozzi',), ('Рос',), ('Rieker',), ('Alessio Nesca',)]
        )
        
        # Поставщики
        cursor.executemany(
            "INSERT INTO suppliers (supplier_name) VALUES (?)",
            [('Kari',), ('Обувь для вас',)]
        )
        
        # Товары
        cursor.executemany(
            """INSERT INTO products (article, product_name, unit_of_measure, price, 
               supplier_id, manufacturer_id, category_id, discount_percent, 
               quantity_in_stock, description, photo_filename) 
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            [
                ('А112Т4', 'Ботинки', 'шт.', 4990, 1, 1, 1, 3, 6, 
                 'Женские Ботинки демисезонные kari', '1.jpg'),
                ('F635R4', 'Ботинки', 'шт.', 3244, 2, 2, 1, 2, 13,
                 'Ботинки Marco Tozzi женские демисезонные', '2.jpg'),
                ('H782T5', 'Туфли', 'шт.', 4499, 1, 1, 2, 4, 5,
                 'Туфли kari мужские классика', '3.jpg'),
                ('G783F5', 'Ботинки', 'шт.', 5900, 1, 3, 2, 2, 8,
                 'Мужские ботинки Рос-Обувь кожаные', '4.jpg'),
                ('J384T6', 'Ботинки', 'шт.', 3800, 2, 4, 2, 2, 16,
                 'Полуботинки мужские Rieker', '5.jpg'),
                ('D572U8', 'Кроссовки', 'шт.', 4100, 2, 3, 2, 3, 6,
                 'Кроссовки мужские', '6.jpg'),
                ('F572H7', 'Туфли', 'шт.', 2700, 1, 2, 1, 2, 14,
                 'Туфли Marco Tozzi женские летние', '7.jpg'),
                ('D329H3', 'Полуботинки', 'шт.', 1890, 2, 5, 1, 4, 4,
                 'Полуботинки Alessio Nesca женские', '8.jpg'),
                ('B320R5', 'Туфли', 'шт.', 4300, 1, 4, 1, 2, 6,
                 'Туфли Rieker женские демисезонные', '9.jpg'),
                ('G432E4', 'Кроссовки', 'шт.', 3200, 1, 1, 2, 18, 10,
                 'Кроссовки мужские Kari спортивные', '10.jpg'),
                ('T123A5', 'Сапоги', 'шт.', 6500, 1, 3, 1, 0, 0,
                 'Сапоги женские зимние', 'picture.png')
            ]
        )
        
        self.connection.commit()
    
    def authenticate_user(self, login, password):
        """Аутентификация пользователя"""
        cursor = self.connection.cursor()
        cursor.execute("""
            SELECT u.user_id, u.full_name, r.role_name 
            FROM users u
            JOIN roles r ON u.role_id = r.role_id
            WHERE u.login = ? AND u.password = ?
        """, (login, password))
        return cursor.fetchone()
    
    def get_all_products(self):
        """Получение всех товаров"""
        cursor = self.connection.cursor()
        cursor.execute("""
            SELECT p.product_id, p.article, p.product_name, c.category_name,
                   p.description, m.manufacturer_name, s.supplier_name,
                   p.price, p.unit_of_measure, p.quantity_in_stock,
                   p.discount_percent, p.photo_filename
            FROM products p
            JOIN categories c ON p.category_id = c.category_id
            JOIN manufacturers m ON p.manufacturer_id = m.manufacturer_id
            JOIN suppliers s ON p.supplier_id = s.supplier_id
            ORDER BY p.product_name
        """)
        return cursor.fetchall()
    
    def close(self):
        """Закрытие соединения с БД"""
        if self.connection:
            self.connection.close()


class LoginWindow:
    """Окно авторизации"""
    
    def __init__(self, root, db_manager, on_login_success):
        self.root = root
        self.db_manager = db_manager
        self.on_login_success = on_login_success
        
        self.root.title("ООО «Обувь» - Вход в систему")
        self.root.geometry("400x350")
        self.root.configure(bg=COLOR_BG)
        self.center_window()
        
        self.create_widgets()
    
    def center_window(self):
        """Центрирование окна на экране"""
        self.root.update_idletasks()
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        x = (self.root.winfo_screenwidth() // 2) - (width // 2)
        y = (self.root.winfo_screenheight() // 2) - (height // 2)
        self.root.geometry(f'{width}x{height}+{x}+{y}')
    
    def create_widgets(self):
        """Создание виджетов окна входа"""
        # Заголовок
        title_frame = tk.Frame(self.root, bg=COLOR_PRIMARY, height=80)
        title_frame.pack(fill=tk.X)
        
        title_label = tk.Label(
            title_frame,
            text="ООО «Обувь»",
            font=("Arial", 20, "bold"),
            bg=COLOR_PRIMARY,
            fg="white"
        )
        title_label.pack(pady=25)
        
        # Основная форма
        form_frame = tk.Frame(self.root, bg=COLOR_BG)
        form_frame.pack(pady=30, padx=40, fill=tk.BOTH, expand=True)
        
        # Логин
        tk.Label(
            form_frame,
            text="Логин:",
            font=("Arial", 11),
            bg=COLOR_BG,
            fg=COLOR_TEXT
        ).grid(row=0, column=0, sticky=tk.W, pady=5)
        
        self.login_entry = tk.Entry(form_frame, font=("Arial", 11), width=30)
        self.login_entry.grid(row=1, column=0, pady=5)
        
        # Пароль
        tk.Label(
            form_frame,
            text="Пароль:",
            font=("Arial", 11),
            bg=COLOR_BG,
            fg=COLOR_TEXT
        ).grid(row=2, column=0, sticky=tk.W, pady=5)
        
        self.password_entry = tk.Entry(form_frame, font=("Arial", 11), width=30, show="*")
        self.password_entry.grid(row=3, column=0, pady=5)
        
        # Кнопки
        button_frame = tk.Frame(form_frame, bg=COLOR_BG)
        button_frame.grid(row=4, column=0, pady=20)
        
        login_button = tk.Button(
            button_frame,
            text="Войти",
            font=("Arial", 11, "bold"),
            bg=COLOR_PRIMARY,
            fg="white",
            width=12,
            height=1,
            command=self.login
        )
        login_button.pack(side=tk.LEFT, padx=5)
        
        guest_button = tk.Button(
            button_frame,
            text="Войти как гость",
            font=("Arial", 11),
            bg=COLOR_BG,
            fg=COLOR_TEXT,
            width=15,
            height=1,
            relief=tk.RIDGE,
            command=self.guest_login
        )
        guest_button.pack(side=tk.LEFT, padx=5)
        
        # Привязка Enter к кнопке входа
        self.root.bind('<Return>', lambda e: self.login())
    
    def login(self):
        """Обработка входа пользователя"""
        login = self.login_entry.get().strip()
        password = self.password_entry.get().strip()
        
        if not login or not password:
            messagebox.showwarning("Ошибка", "Введите логин и пароль!")
            return
        
        user_data = self.db_manager.authenticate_user(login, password)
        
        if user_data:
            user_id, full_name, role_name = user_data
            self.on_login_success(user_id, full_name, role_name)
        else:
            messagebox.showerror("Ошибка", "Неверный логин или пароль!")
            self.password_entry.delete(0, tk.END)
    
    def guest_login(self):
        """Вход в режиме гостя"""
        self.on_login_success(None, "Гость", "Гость")


class MainApplication:
    """Главное окно приложения"""
    
    def __init__(self, root):
        self.root = root
        self.db_manager = DatabaseManager()
        self.db_manager.import_initial_data()
        
        self.current_user_id = None
        self.current_user_name = None
        self.current_user_role = None
        
        self.show_login_window()
    
    def show_login_window(self):
        """Показать окно входа"""
        # Очистка главного окна
        for widget in self.root.winfo_children():
            widget.destroy()
        
        LoginWindow(self.root, self.db_manager, self.on_login_success)
    
    def on_login_success(self, user_id, user_name, user_role):
        """Обработка успешного входа"""
        self.current_user_id = user_id
        self.current_user_name = user_name
        self.current_user_role = user_role
        
        self.show_main_interface()
    
    def show_main_interface(self):
        """Показать главный интерфейс"""
        # Очистка окна
        for widget in self.root.winfo_children():
            widget.destroy()
        
        self.root.title(f"ООО «Обувь» - {self.current_user_role}")
        self.root.geometry("1200x700")
        self.root.configure(bg=COLOR_BG)
        
        self.create_main_widgets()
    
    def create_main_widgets(self):
        """Создание виджетов главного интерфейса"""
        # Шапка
        header_frame = tk.Frame(self.root, bg=COLOR_PRIMARY, height=60)
        header_frame.pack(fill=tk.X)
        header_frame.pack_propagate(False)
        
        title_label = tk.Label(
            header_frame,
            text="ООО «Обувь» - Каталог товаров",
            font=("Arial", 16, "bold"),
            bg=COLOR_PRIMARY,
            fg="white"
        )
        title_label.pack(side=tk.LEFT, padx=20, pady=15)
        
        # Имя пользователя в правом верхнем углу
        user_frame = tk.Frame(header_frame, bg=COLOR_PRIMARY)
        user_frame.pack(side=tk.RIGHT, padx=20, pady=10)
        
        tk.Label(
            user_frame,
            text=self.current_user_name,
            font=("Arial", 11, "bold"),
            bg=COLOR_PRIMARY,
            fg="white"
        ).pack(side=tk.TOP)
        
        tk.Label(
            user_frame,
            text=f"Роль: {self.current_user_role}",
            font=("Arial", 9),
            bg=COLOR_PRIMARY,
            fg="white"
        ).pack(side=tk.TOP)
        
        logout_button = tk.Button(
            user_frame,
            text="Выход",
            font=("Arial", 9),
            bg="white",
            fg=COLOR_PRIMARY,
            command=self.show_login_window
        )
        logout_button.pack(side=tk.TOP, pady=5)
        
        # Панель инструментов (если нужно)
        toolbar_frame = tk.Frame(self.root, bg="white", height=50)
        toolbar_frame.pack(fill=tk.X, padx=10, pady=5)
        
        # Информационная метка
        info_text = "Список товаров магазина"
        if self.current_user_role == "Гость":
            info_text += " (Режим гостя: базовый просмотр)"
        
        tk.Label(
            toolbar_frame,
            text=info_text,
            font=("Arial", 10),
            bg="white",
            fg=COLOR_TEXT
        ).pack(side=tk.LEFT, padx=10, pady=10)
        
        # Список товаров
        self.create_products_list()
    
    def create_products_list(self):
        """Создание списка товаров"""
        # Контейнер для списка товаров с прокруткой
        container_frame = tk.Frame(self.root, bg=COLOR_BG)
        container_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Canvas для прокрутки
        canvas = tk.Canvas(container_frame, bg=COLOR_BG, highlightthickness=0)
        scrollbar = tk.Scrollbar(container_frame, orient=tk.VERTICAL, command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, bg=COLOR_BG)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor=tk.NW)
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Получение товаров
        products = self.db_manager.get_all_products()
        
        # Отображение товаров
        for i, product in enumerate(products):
            self.create_product_card(scrollable_frame, product, i)
        
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Привязка прокрутки колесом мыши
        def on_mousewheel(event):
            canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        canvas.bind_all("<MouseWheel>", on_mousewheel)
    
    def create_product_card(self, parent, product, index):
        """Создание карточки товара"""
        (product_id, article, name, category, description, manufacturer,
         supplier, price, unit, quantity, discount, photo) = product
        
        # Вычисление итоговой цены
        final_price = price * (1 - discount / 100)
        
        # Определение цвета фона
        bg_color = "white"
        if discount > 15:
            bg_color = COLOR_SUCCESS
        elif quantity == 0:
            bg_color = COLOR_INFO
        
        # Создание карточки
        card_frame = tk.Frame(
            parent,
            bg=bg_color,
            relief=tk.RIDGE,
            borderwidth=2
        )
        card_frame.grid(row=index, column=0, sticky=tk.EW, pady=5, padx=5)
        parent.grid_columnconfigure(0, weight=1)
        
        # Левая часть - информация о товаре
        info_frame = tk.Frame(card_frame, bg=bg_color)
        info_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=15, pady=10)
        
        # Артикул и название
        tk.Label(
            info_frame,
            text=f"{name} (Арт: {article})",
            font=("Arial", 12, "bold"),
            bg=bg_color,
            fg=COLOR_TEXT,
            anchor=tk.W
        ).pack(anchor=tk.W)
        
        # Категория
        tk.Label(
            info_frame,
            text=f"Категория: {category}",
            font=("Arial", 10),
            bg=bg_color,
            fg=COLOR_TEXT,
            anchor=tk.W
        ).pack(anchor=tk.W, pady=2)
        
        # Описание
        tk.Label(
            info_frame,
            text=f"Описание: {description}",
            font=("Arial", 9),
            bg=bg_color,
            fg=COLOR_TEXT,
            anchor=tk.W,
            wraplength=500
        ).pack(anchor=tk.W, pady=2)
        
        # Производитель и поставщик
        tk.Label(
            info_frame,
            text=f"Производитель: {manufacturer} | Поставщик: {supplier}",
            font=("Arial", 9),
            bg=bg_color,
            fg=COLOR_TEXT,
            anchor=tk.W
        ).pack(anchor=tk.W, pady=2)
        
        # Правая часть - цена и количество
        price_frame = tk.Frame(card_frame, bg=bg_color)
        price_frame.pack(side=tk.RIGHT, padx=15, pady=10)
        
        # Цена
        if discount > 0:
            # Старая цена (зачеркнутая)
            old_price_label = tk.Label(
                price_frame,
                text=f"{price:.2f} руб.",
                font=("Arial", 11, "overstrike"),
                bg=bg_color,
                fg=COLOR_DANGER
            )
            old_price_label.pack()
            
            # Новая цена
            tk.Label(
                price_frame,
                text=f"{final_price:.2f} руб.",
                font=("Arial", 13, "bold"),
                bg=bg_color,
                fg="black"
            ).pack()
        else:
            tk.Label(
                price_frame,
                text=f"{price:.2f} руб.",
                font=("Arial", 13, "bold"),
                bg=bg_color,
                fg="black"
            ).pack()
        
        # Единица измерения
        tk.Label(
            price_frame,
            text=f"за {unit}",
            font=("Arial", 9),
            bg=bg_color,
            fg=COLOR_TEXT
        ).pack()
        
        # Количество на складе
        quantity_text = f"На складе: {quantity} шт."
        quantity_color = COLOR_DANGER if quantity == 0 else COLOR_TEXT
        
        tk.Label(
            price_frame,
            text=quantity_text,
            font=("Arial", 10, "bold"),
            bg=bg_color,
            fg=quantity_color
        ).pack(pady=5)
        
        # Скидка
        if discount > 0:
            tk.Label(
                price_frame,
                text=f"Скидка: {discount}%",
                font=("Arial", 10, "bold"),
                bg=bg_color,
                fg=COLOR_SUCCESS
            ).pack()


def main():
    """Главная функция запуска приложения"""
    root = tk.Tk()
    app = MainApplication(root)
    root.mainloop()
    
    # Закрытие БД при выходе
    app.db_manager.close()


if __name__ == "__main__":
    main()
